package com.google.sqliteexample;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.jar.Attributes;

class SQLite extends SQLiteOpenHelper {
    public SQLite(Context context) {
        super(context, "DBASE", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table stud(RNO TEXT, NAME TEXT, ADDRESS TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists stud");
        onCreate(db);
    }

    public boolean insertData(String RNO, String Name, String Address) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("RNO", RNO);
        contentValues.put("NAME", Name);
        contentValues.put("ADDRESS", Address);
        long res = db.insert("stud",null, contentValues);

        if(res == -1)
            return false;
        else
            return true;
    }

    public boolean updateData(String RNO, String Name, String Address) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("NAME", Name);
        contentValues.put("ADDRESS", Address);
        db.update("stud", contentValues, "RNO="+RNO,null);
        return true;
    }

    public boolean delData(String RNO) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("stud","RNO="+RNO,null);
        return true;
    }

    public Cursor readData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from stud", null);
        return cursor;
    }
}