package com.google.sqliteexample;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    EditText e_rno, e_name, e_add;
    Button b_add, b_view, b_edit, b_del;
    TableLayout tb1;
    SQLite sqLite;

    public void references() {

        e_rno = findViewById(R.id.e_rno);
        e_name = findViewById(R.id.e_name);
        e_add = findViewById(R.id.e_address);

        b_add = findViewById(R.id.b_add);
        b_edit = findViewById(R.id.b_edit);
        b_del = findViewById(R.id.b_del);
        b_view = findViewById(R.id.b_view);

        tb1 = findViewById(R.id.tb1);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        references();

        sqLite = new SQLite(this);

        b_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String rno = e_rno.getText().toString();
                String name = e_name.getText().toString();
                String add = e_add.getText().toString();

                if (rno.equals("") && name.equals("") && add.equals("")) {
                    Toast.makeText(MainActivity.this, "Data is Empty", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean data = sqLite.insertData(rno,name,add);
                    Toast.makeText(MainActivity.this, "Record Inserted Successfully", Toast.LENGTH_SHORT).show();
                }

            }
        });

        b_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String rno = e_rno.getText().toString();
                String name = e_name.getText().toString();
                String add = e_add.getText().toString();

                if (rno.equals("") && name.equals("") && add.equals("")) {
                    Toast.makeText(MainActivity.this, "Data is Empty", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean data = sqLite.updateData(rno, name, add);

                    if (data == false) {
                        Toast.makeText(MainActivity.this, "Something is wrong in the database", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Record Updated Successfully", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        b_del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String rno = e_rno.getText().toString();

                if (rno.equals("")) {
                    Toast.makeText(getApplicationContext(), "Data is Empty", Toast.LENGTH_SHORT).show();
                } else {
                    boolean data = sqLite.delData(rno);
                    if (data == false) {
                        Toast.makeText(getApplicationContext(), "Something is wrong in the database", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Record Deleted Successfully", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        b_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Cursor data = sqLite.readData();

                if(data.getCount() == 0){
                    Toast.makeText(getApplicationContext(),"No Data to fetch",Toast.LENGTH_SHORT).show();
                } else {

                    tb1.removeAllViews();
                    tb1=findViewById(R.id.tb1);
                    TableRow thr = new TableRow(getApplicationContext());
                    thr.setBackgroundColor(Color.rgb(58,58,56));
                    TextView th1 = new TextView(getApplicationContext());
                    TextView th2 = new TextView(getApplicationContext());
                    TextView th3 = new TextView(getApplicationContext());
                    th1.setPadding(30,30,30,30);
                    th2.setPadding(30,30,30,30);
                    th3.setPadding(30,30,30,30);
                    th1.setText("rno");
                    th2.setText("name");
                    th3.setText("add");
                    thr.addView(th1);
                    thr.addView(th2);
                    thr.addView(th3);
                    tb1.addView(thr);
                    while(data.moveToNext()){
                        TableRow tr = new TableRow(getApplicationContext());
                        tr.setBackgroundColor(Color.rgb(150,145,56));
                        TextView tv1 = new TextView(getApplicationContext());
                        TextView tv2 = new TextView(getApplicationContext());
                        TextView tv3 = new TextView(getApplicationContext());
                        tv1.setPadding(30,30,30,30);
                        tv2.setPadding(30,30,30,30);
                        tv3.setPadding(30,30,30,30);
                        tv1.setText(data.getString(0));
                        tv2.setText(data.getString(1));
                        tv3.setText(data.getString(2));
                        tr.addView(tv1);
                        tr.addView(tv2);
                        tr.addView(tv3);
                        tr.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                e_rno.setText(tv1.getText());
                                e_name.setText(tv2.getText());
                                e_add.setText(tv3.getText());
                            }
                        });
                        tb1.addView(tr);
                    }

                }
            }
        });
    }
}